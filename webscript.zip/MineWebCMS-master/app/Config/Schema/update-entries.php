<?php
// Array des modifications à executer

/*
Exemple :
$updateContent = array(
  'configuration' => array(
    array(
      'create' => array(
        array('name' => '1', 'name2' => '2', 'name3' => '3'),
        array('name' => '1bis', 'name2' => '2bis', 'name3' => '3bis')
      ),
      'update' => array(
        array('id' => '19', 'name' => 'new name')
      )
    )
  )
)
*/

$updateEntries = array();
?>
