<?php
class Slider extends AppModel {
}